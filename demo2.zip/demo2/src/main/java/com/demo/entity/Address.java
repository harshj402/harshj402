package com.demo.entity;

import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Embeddable
@Setter
@Getter
@ToString
@NoArgsConstructor
@ApiModel
public class Address {
    
	@ApiModelProperty
    private String street;
    
	@ApiModelProperty
    private String city;
    
	@ApiModelProperty
    private String state;
    
	@ApiModelProperty
    private String zip;
    

    @ElementCollection
    @ApiModelProperty
    private List<String> phoneNumbers;
}
