package com.demo.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@Entity
@ApiModel
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    private String name;
    
    private int age;
    
    @Embedded
    private Address address;
    
    //@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    @ApiModelProperty
    public Address getAddress() {
        return address;
    }

	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}



	public void setAddress(Address address) {
		this.address = address;
	}

	
	@Override
	public String toString() {
		return String.format("User [id=%s, name=%s, age=%s, address=%s]", id, name, age, address);
	}

}

