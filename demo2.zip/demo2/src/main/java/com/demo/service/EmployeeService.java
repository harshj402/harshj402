package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.demo.customexception.ResourceNotFoundException;
import com.demo.entity.Employee;
import com.demo.repo.EmployeeRepository;
import org.springframework.data.domain.Pageable;


@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Employee getEmployeeById(Long id) throws ResourceNotFoundException {
        return employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee", "id", id));
    }

    public Employee createEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public Employee updateEmployee(Long id, Employee employeeDetails) throws ResourceNotFoundException {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee", "id", id));

        employee.setFirstName(employeeDetails.getFirstName());
        employee.setLastName(employeeDetails.getLastName());
        employee.setEmail(employeeDetails.getEmail());
        employee.setDepartment(employeeDetails.getDepartment());

        return employeeRepository.save(employee);
    }

    public ResponseEntity<?> deleteEmployee(Long id) throws ResourceNotFoundException {
        Employee employee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee", "id", id));

        employeeRepository.delete(employee);

        return ResponseEntity.ok().build();
    }
    
    
    public List<Employee> findByDepartment(String department, int page, int size) throws ResourceNotFoundException {
      List<Employee> employees = null;
      Pageable paging = PageRequest.of(page, size);

      if (department != null) {
        employees = employeeRepository.findByDepartment(department, paging);
      } else {
        employees = employeeRepository.findAll(paging).getContent();
      }

      if (employees.isEmpty()) {
        throw new ResourceNotFoundException("No employees found.");
      } else {
        return employees;
      }
    }

}
